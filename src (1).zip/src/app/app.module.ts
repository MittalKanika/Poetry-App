import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { HttpModule } from '@angular/http';
import { SocialSharing } from '@ionic-native/social-sharing';
import { Clipboard } from '@ionic-native/clipboard';
import { Facebook } from '@ionic-native/facebook';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { RegisterPage } from '../pages/register/register';
import { AddpoetryPage } from '../pages/addpoetry/addpoetry';
import { PoetryPage } from '../pages/poetry/poetry';
import { QoutesPage } from '../pages/qoutes/qoutes';
import { FunnyPage } from '../pages/funny/funny';
import { ProfilePage } from '../pages/profile/profile';
import { SinglePage } from '../pages/single/single';
import { AuthorsPage } from '../pages/authors/authors';
import { SettingsPage } from '../pages/settings/settings';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { IonicStorageModule } from '@ionic/storage';
import { File } from '@ionic-native/file';
import { Transfer } from '@ionic-native/transfer';
import { FilePath } from '@ionic-native/file-path';
import { Camera } from '@ionic-native/camera';


@NgModule({
  declarations: [
    MyApp,
    HomePage,
    LoginPage,
    RegisterPage,
    AddpoetryPage,
    PoetryPage,
    QoutesPage,
    FunnyPage,
    ProfilePage,
    SinglePage,
    AuthorsPage,
    SettingsPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot(),
    HttpModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    LoginPage,
    RegisterPage,
    AddpoetryPage,
    PoetryPage,
    QoutesPage,
    FunnyPage,
    ProfilePage,
    SinglePage,
    AuthorsPage,
    SettingsPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    File,
    Transfer,
    FilePath,
    Camera,
    SocialSharing,
    Clipboard,
    Facebook,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
