import { Component, ViewChild } from '@angular/core';
import { Nav, Platform,Events} from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';

import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { AddpoetryPage } from '../pages/addpoetry/addpoetry';
import { ProfilePage } from '../pages/profile/profile';
import { AuthorsPage } from '../pages/authors/authors';
import { SettingsPage } from '../pages/settings/settings';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;
  rootPage: any = LoginPage;
  image:any;
  name:any;
  bgimage:any;
  pages: Array<{title: string, component: any}>;

  constructor( public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen, private storage:Storage, public events:Events, private http: Http) {
    this.initializeApp();
    this.events.subscribe('userloggedin',(() => {
    this.storage.get('data').then((data) => {
      if(data.name){
        this.name = data.name;
      }
      if(data.user_id){
        this.http.get('http://punjabipakwan.com/api/getbgimage.php?id='+ data.user_id).map(response => response.json()).subscribe(data => {
          console.log(data.Response.data);
            if(data.success == true){
                this.bgimage = data.Response.data[0].img;
            }else {
              this.bgimage = 'http://punjabipakwan.com/api/upload/bg.jpg';
            }
        },(error => {
          //this.loginError = "Wrong Email or Password";
        }));
      }
      if(data.image != ''){
        this.image = data.image;
      }else {
        this.image = 'http://via.placeholder.com/150x150';
      }
    })
    }));

    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'Home', component: HomePage },
      {title: 'Add Post', component:AddpoetryPage},
      {title: 'Authors', component:AuthorsPage},
      {title: 'Settings', component:SettingsPage},
      {title: 'Logout', component: null}
    ];
  }
  profile(){
    this.nav.push(ProfilePage);
  }
  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
  openPage(page) {
    if(page.component) {
      this.nav.setRoot(page.component);
    }else {
      //Logout Removing the token save in storage
      this.storage.remove('data');
      this.events.unsubscribe('userloggedin');
      this.nav.setRoot(LoginPage);
    }
  }
}
