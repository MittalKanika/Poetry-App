import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, Loading } from 'ionic-angular';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import { PoetryPage } from '../poetry/poetry';
import { QoutesPage } from '../qoutes/qoutes';
import { FunnyPage } from '../funny/funny';

@IonicPage()
@Component({
  selector: 'page-addpoetry',
  templateUrl: 'addpoetry.html',
})
export class AddpoetryPage {
  title:any;
  category:any;
  sub_category:any;
  poet_name:any;
  content:any;
  postSuccess:string;
  postError:string;
  loading: Loading;
  bgimage:any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private http: Http, public storage:Storage, private toastCtrl:ToastController, public loadingCtrl: LoadingController) {
    this.title;
    this.category;
    this.sub_category;
    this.poet_name;
    this.content;
  }
  ionViewDidLoad(){
    this.storage.get('data').then((data) => {
      if(data.user_id){
        this.http.get('http://punjabipakwan.com/api/getbgimage.php?id='+ data.user_id).map(response => response.json()).subscribe(data => {
          console.log(data.Response.data);
            if(data.success == true){
                this.bgimage = data.Response.data[0].img;
            }else {
              this.bgimage = 'http://punjabipakwan.com/api/upload/bg.jpg';
            }
        },(error => {
        }));
      }
    })
  }
  submit(){ 
    if(this.title !== '' && this.category !== '' && this.content !== ''){
      this.loading = this.loadingCtrl.create({
        content: 'Submitting...',
      });
      this.loading.present();
      this.storage.get('data').then((data) => {
        let content2 = this.content.replace(new RegExp('\n', 'g'), "<br />");
        let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'});
          let options = new RequestOptions({ headers: headers });
          let body = {
            "user_id":data.user_id,
            "title":this.title,
            "category": this.category,
            "sub_category": this.sub_category,
            "poet_name":this.poet_name,
            "content": content2
          }
          this.http.post('http://punjabipakwan.com/api/addpost.php', body, options).map(response => response.json()).subscribe(data => {
              if(data.success !== true){
                this.loading.dismissAll();
                this.presentToast('An Unknown error occured. Please try again.');
              }else {
                this.loading.dismissAll();
                this.presentToast('Your post will be published after review.');
                if(this.category == "poetry"){
                    this.navCtrl.push(PoetryPage);
                }else if(this.category == "qoutes"){
                    this.navCtrl.push(QoutesPage);
                }else if(this.category == "jokes"){
                   this.navCtrl.push(FunnyPage);  
                }
              }
          },(error => {
            this.loading.dismissAll();
            this.presentToast('An Unknown error occured. Please try again.');
          }));
        });
    }else {
      this.presentToast('Please Fill all the fields');
    }
  }
  private presentToast(text) {
    let toast = this.toastCtrl.create({
      message: text,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

}
