import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddpoetryPage } from './addpoetry';

@NgModule({
  declarations: [
    AddpoetryPage,
  ],
  imports: [
    IonicPageModule.forChild(AddpoetryPage),
  ],
})
export class AddpoetryPageModule {}
