import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { Http} from '@angular/http';
import { Storage } from '@ionic/storage';
import { SocialSharing } from '@ionic-native/social-sharing';
import { Clipboard } from '@ionic-native/clipboard';

@IonicPage()
@Component({
  selector: 'page-single',
  templateUrl: 'single.html',
})
export class SinglePage {
  item:any;
  post_id:any;
  comments:any;
  content:any;
  bgimage:any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private http: Http, public storage:Storage, private toastCtrl:ToastController, private socialSharing: SocialSharing, private clipboard:Clipboard) {
    this.content;
  }
  ionViewDidLoad(){
    let id = this.navParams.get("id");
    this.postload(id);
    this.commentsLoad(id);
    this.storage.get('data').then((data) => {
      if(data.user_id){
        this.http.get('http://punjabipakwan.com/api/getbgimage.php?id='+ data.user_id).map(response => response.json()).subscribe(data => {
          console.log(data.Response.data);
            if(data.success == true){
                this.bgimage = data.Response.data[0].img;
            }else {
              this.bgimage = 'http://punjabipakwan.com/api/upload/bg.jpg';
            }
        },(error => {
          //this.loginError = "Wrong Email or Password";
        }));
      }
    })
  }
  private postload = function(id){
    this.http.get('http://punjabipakwan.com/api/single.php?id='+id).map(response => response.json()).subscribe(data => {
      console.log(data.Response.data[0].post_text);
      if(data.success !== true){
        }else {
          this.item = data.Response.data[0].post_text;
          this.post_id = data.Response.data[0].id;
          
        }
    },(error => {
    }));
  }
  private commentsLoad = function(id){
    this.http.get('http://punjabipakwan.com/api/comments.php?action=get_comments&id='+id).map(response => response.json()).subscribe(data => {
      console.log(data.Response.data);
        if(data.success !== true){
            //this.loginError = "Wrong Email or Password";
        }else {
          this.comments = data.Response.data;
          
        }
    },(error => {
    }));
 }
  compilemsg():string{
    var msg = this.item ;
    msg = msg.replace(/<br\s*\/?>/mg,"\n");
    return msg.concat(" \n\n Sent from Funbook !");
  }
  copyText(){
    var msg = this.compilemsg();
    this.clipboard.copy(msg);
    this.presentToast('Text copied to clipboard');
  }
  regularShare(){
    var msg = this.compilemsg();
    this.socialSharing.share(msg, null, null, null);
  }
  whatsappShare(){
    var msg  = this.compilemsg();
     this.socialSharing.shareViaWhatsApp(msg, null, null);
   }
   twitterShare(){
    var msg  = this.compilemsg();
    this.socialSharing.shareViaTwitter(msg, null, null);
  }
  facebookShare(){
    var msg  = this.compilemsg();
    this.socialSharing.shareViaFacebook(msg, null, null);
  }
  submit(id){
    let content = this.content;
    if(content){
      this.http.get('http://punjabipakwan.com/api/comments.php?action=post_comments&content='+content+'&id='+id).map(response => response.json()).subscribe(data => {
          this.content = '';
          this.presentToast('Comment Posted');
          this.postload(id);
          this.commentsLoad(id);
      },(error => {
      }));
    }else {}
  }
  private presentToast(text) {
    let toast = this.toastCtrl.create({
      message: text,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

}