import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController, LoadingController, Loading } from 'ionic-angular';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import { LoginPage } from '../login/login';

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  name:any;
  email:any;
  password:any;
  error: string;
  loading: Loading;
  bgimage:any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private http: Http, public storage:Storage, private toastCtrl:ToastController, public loadingCtrl: LoadingController) {
    this.name;
    this.email;
    this.password;
  }
  ionViewDidLoad(){
    this.bgimage = 'http://punjabipakwan.com/api/upload/bg.jpg';
  }
  register(){ 
    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    if(validateEmail(this.email) == false){
      this.presentToast('Please Enter a valid email address');
    }else {
      this.error="";
      if(this.name != '' && this.email != '' && this.password != '' && this.error == ''){
          this.loading = this.loadingCtrl.create({
            content: 'Please Wait...',
          });
          this.loading.present();
          let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'});
            let options = new RequestOptions({ headers: headers });
            let body = {
              "name":this.name,
              "email": this.email,
              "password": this.password
            }
            this.http.post('http://punjabipakwan.com/api/register.php', body, options).map(response => response.json()).subscribe(data => {
                if(data.success !== true){
                  this.loading.dismissAll();
                  this.presentToast('Wrong Email or Password');
                }else {
                  this.loading.dismissAll();
                  this.presentToast('Your account is activated successfully');
                  this.name="";
                  this.email="";
                  this.password="";
                }
            },(error => {
              this.loading.dismissAll();
              this.presentToast('Wrong Email or Password');
            }));
      }else {
        this.presentToast('Please Fill all the fields');
      }
    }
  }
  login(){
    this.navCtrl.setRoot(LoginPage);
  }
  private presentToast(text) {
    let toast = this.toastCtrl.create({
      message: text,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }
}

