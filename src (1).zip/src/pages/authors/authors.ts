import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Http} from '@angular/http';
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
  selector: 'page-authors',
  templateUrl: 'authors.html',
})
export class AuthorsPage {
  users:any;
  image:any;
  bgimage:any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private http:Http, public storage:Storage) {
  }

 ionViewDidLoad() {
    this.image = 'http://via.placeholder.com/150x150';
    
    this.storage.get('data').then((data) => {
      if(data.user_id){
        this.http.get('http://punjabipakwan.com/api/getbgimage.php?id='+ data.user_id).map(response => response.json()).subscribe(data => {
          console.log(data.Response.data);
            if(data.success == true){
                this.bgimage = data.Response.data[0].img;
            }else {
              this.bgimage = 'http://punjabipakwan.com/api/upload/bg.jpg';
            }
        },(error => {
          //this.loginError = "Wrong Email or Password";
        }));
      }
    })
    this.postload();

  }
  private postload = function(){
    this.http.get('http://punjabipakwan.com/api/getusers.php').map(response => response.json()).subscribe(data => {
        console.log(data.Response.data);
        if(data.success !== true){
        }else {
          this.users = data.Response.data;
        }
    },(error => {
    }));
  }
  alphabatical(){
    this.postload();
  }

  popular(){
    this.http.get('http://punjabipakwan.com/api/getusers.php?sorting=popular').map(response => response.json()).subscribe(data => {
        console.log(data.Response.data);
        if(data.success !== true){
        }else {
          this.users = data.Response.data;
        }
    },(error => {
    }));
  }




}
