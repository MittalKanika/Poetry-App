import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FunnyPage } from './funny';

@NgModule({
  declarations: [
    FunnyPage,
  ],
  imports: [
    IonicPageModule.forChild(FunnyPage),
  ],
})
export class FunnyPageModule {}
