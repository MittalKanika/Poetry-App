import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,MenuController, ToastController } from 'ionic-angular';
import { Http} from '@angular/http';
import { Storage } from '@ionic/storage';
import { SocialSharing } from '@ionic-native/social-sharing';
import { Clipboard } from '@ionic-native/clipboard';

@IonicPage()
@Component({
  selector: 'page-funny',
  templateUrl: 'funny.html',
})
export class FunnyPage {
  jokes:any;
  bgimage:any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private http: Http, public storage:Storage, public menuCtrl: MenuController, private socialSharing: SocialSharing, private clipboard:Clipboard, private toastCtrl:ToastController,) {
    this.menuCtrl.enable(true, 'mainMenu');
  }
  ionViewDidLoad(){
    console.log('page loaded');
    this.http.get('http://punjabipakwan.com/api/getpost.php?category=jokes').map(response => response.json()).subscribe(data => {
      console.log(data.Responce.data);
        if(data.success !== true){
            //this.loginError = "Wrong Email or Password";
        }else {
          this.jokes = data.Responce.data;
        }
    },(error => {
      //this.loginError = "Wrong Email or Password";
    }));
    this.storage.get('data').then((data) => {
      if(data.user_id){
        this.http.get('http://punjabipakwan.com/api/getbgimage.php?id='+ data.user_id).map(response => response.json()).subscribe(data => {
          console.log(data.Response.data);
            if(data.success == true){
                this.bgimage = data.Response.data[0].img;
            }else {
              this.bgimage = 'http://punjabipakwan.com/api/upload/bg.jpg';
            }
        },(error => {
          //this.loginError = "Wrong Email or Password";
        }));
      }
    })
  }
  compilemsg(index):string{
    var msg = this.jokes[index].post_text ;
    msg = msg.replace(/<br\s*\/?>/mg,"\n");
    return msg.concat(" \n\n Sent from Funbook !");
  }
  copyText(index){
    var msg = this.compilemsg(index);
    this.clipboard.copy(msg);
    this.presentToast('Text copied to clipboard');
  }
  regularShare(index){
    var msg = this.compilemsg(index);
    this.socialSharing.share(msg, null, null, null);
  }
  whatsappShare(index){
    var msg  = this.compilemsg(index);
     this.socialSharing.shareViaWhatsApp(msg, null, null);
   }
   twitterShare(index){
    var msg  = this.compilemsg(index);
    this.socialSharing.shareViaTwitter(msg, null, null);
  }
  facebookShare(index){
    var msg  = this.compilemsg(index);
    this.socialSharing.shareViaFacebook(msg, null, null);
  }
  private presentToast(text) {
    let toast = this.toastCtrl.create({
      message: text,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }

}
