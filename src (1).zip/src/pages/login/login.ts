import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,MenuController, ToastController, LoadingController, Loading } from 'ionic-angular';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Storage } from '@ionic/storage';
import { Events } from 'ionic-angular';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

import { HomePage } from '../home/home';
import { RegisterPage } from '../register/register';
import { ProfilePage } from '../profile/profile';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  email:any;
  password:any;
  error: string;
  loading: Loading;
  bgimage:any;
  constructor(public navCtrl: NavController, public navParams: NavParams, private http: Http, public storage:Storage, public events:Events, public menuCtrl: MenuController, private toastCtrl:ToastController, public loadingCtrl: LoadingController) {
    this.menuCtrl.enable(false, 'mainMenu');
    this.email;
    this.password;
  }
  ionViewDidLoad(){
    this.storage.get('data').then((data) => {
        if(data !== null){
          this.navCtrl.setRoot(HomePage);
          this.events.publish('userloggedin', data);
          
        }else {}
    })
    this.bgimage = 'http://punjabipakwan.com/api/upload/bg.jpg';
    
  }
  login(){ 
    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    if(validateEmail(this.email) == false){
      this.presentToast('Wrong Email or Password');
    }else {
      this.error="";
      if(this.email != '' && this.password != '' && this.error == ''){
        this.loading = this.loadingCtrl.create({
          content: 'Loggin in...',
        });
        this.loading.present();
        let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'});
            let options = new RequestOptions({ headers: headers });
            let body = {
              "email": this.email,
              "password": this.password
            }
            this.http.post('http://punjabipakwan.com/api/login.php', body, options).map(response => response.json()).subscribe(data => {
                if(data.success !== true){
                    this.presentToast('Wrong Email or Password');
                    this.loading.dismissAll();
                }else {
                  console.log(data.Response.data);
                  if(data.Response.data.user_gender == null){
                      this.loading.dismissAll();
                      this.storage.set('data', data.Response.data);
                      this.navCtrl.setRoot(ProfilePage);
                      this.events.publish('userloggedin', data.Response.data);
                  }else {
                    this.loading.dismissAll();
                    this.storage.set('data', data.Response.data);
                    this.navCtrl.setRoot(HomePage);
                    this.events.publish('userloggedin', data.Response.data);
                  }
                }
            },(error => {
              this.loading.dismissAll();
              this.presentToast('Wrong Email or Password');
            }));
      }else {
        this.presentToast('Please Fill all the fields');
      }
    }
  }
  private presentToast(text) {
    let toast = this.toastCtrl.create({
      message: text,
      duration: 3000,
      position: 'top'
    });
    toast.present();
  }
  createAccount(){
    this.navCtrl.push(RegisterPage);
  }

}
