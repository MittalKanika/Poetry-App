import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PoetryPage } from './poetry';

@NgModule({
  declarations: [
    PoetryPage,
  ],
  imports: [
    IonicPageModule.forChild(PoetryPage),
  ],
})
export class PoetryPageModule {}
